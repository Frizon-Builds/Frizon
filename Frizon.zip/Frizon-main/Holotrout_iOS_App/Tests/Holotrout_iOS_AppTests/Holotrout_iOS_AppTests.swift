import XCTest
@testable import Holotrout_iOS_App

final class Holotrout_iOS_AppTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(Holotrout_iOS_App().text, "Hello, World!")
    }
}
